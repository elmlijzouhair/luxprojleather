// Header scroll behavior
document.addEventListener('DOMContentLoaded', function() {
  const header = document.querySelector('[data-header]');
  
  if (header) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 0) {
        header.classList.add('site-header--scrolled');
      } else {
        header.classList.remove('site-header--scrolled');
      }
    });
  }
});

// Product variant selector
document.addEventListener('DOMContentLoaded', function() {
  const variantSelectors = document.querySelectorAll('[data-variant-selector]');
  
  variantSelectors.forEach(selector => {
    selector.addEventListener('change', function(event) {
      const variantId = event.target.value;
      const addToCartButton = document.querySelector('[data-add-to-cart]');
      const priceElement = document.querySelector('[data-product-price]');
      
      if (addToCartButton) {
        addToCartButton.disabled = !variantId;
      }
      
      // Update price if variant changes
      if (priceElement && window.productVariants) {
        const variant = window.productVariants.find(v => v.id === parseInt(variantId));
        if (variant) {
          priceElement.textContent = formatMoney(variant.price);
        }
      }
    });
  });
});

// Cart drawer functionality
class CartDrawer {
  constructor() {
    this.drawer = document.querySelector('[data-cart-drawer]');
    this.openButton = document.querySelector('[data-cart-drawer-open]');
    this.closeButton = document.querySelector('[data-cart-drawer-close]');
    this.bindEvents();
  }

  bindEvents() {
    if (this.openButton) {
      this.openButton.addEventListener('click', () => this.open());
    }
    if (this.closeButton) {
      this.closeButton.addEventListener('click', () => this.close());
    }
  }

  open() {
    this.drawer?.classList.remove('translate-x-full');
    document.body.style.overflow = 'hidden';
  }

  close() {
    this.drawer?.classList.add('translate-x-full');
    document.body.style.overflow = '';
  }
}

// Initialize cart drawer
document.addEventListener('DOMContentLoaded', function() {
  new CartDrawer();
});

// Helper functions
function formatMoney(cents) {
  return (cents / 100).toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD'
  });
}